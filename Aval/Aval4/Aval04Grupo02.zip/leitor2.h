#include "macros.h"
#include <pthread.h>
#define NB_THREADS 3
